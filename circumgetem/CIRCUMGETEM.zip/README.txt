﻿
For CSS3, we use border-radius for our buttons. We do use buttons and we do style it using paddings, 
font-sizes, and use the hover pseudoclass to change the background color. We also use shadows on our
buttons. 

We used JQuery for our JavaScript library.

We were able to implement selection boxes on the canvas to indicate what square you've selected 
to put on the grid. We've added a counter to both the amount of triangles the user has collected, 
and the number of waves the user has finished. We've created a pseudo-random generator to generate
a random number of enemy circles. There's collision detection between the circles and squares. 
We've added hovering over the selection boxes to make sure the user knows what square they're about
to put on the grid. There is a start menu that asks for the user's name and then proceeds the game.
We've also added different types of squares and circles with different abilities in this game.
There are mainly 3 different abilities.